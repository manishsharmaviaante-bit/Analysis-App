package com.manish.analysis

import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import java.util.Calendar

class MainActivity : AppCompatActivity() {
    private lateinit var chart: ChartView
    private var selectedUri: Uri? = null

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedUri = uri
            chart.setImage(MediaStore.Images.Media.getBitmap(contentResolver, uri))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(8,11,16))
        }
        root.addView(TextView(this).apply {
            text = "ANALYSIS\nby Manish Sharma"
            textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        })
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val upload = MaterialButton(this).apply { text = "UPLOAD CHART" }
        val analyse = MaterialButton(this).apply { text = "ANALYSE" }
        controls.addView(upload, LinearLayout.LayoutParams(0, 60, 1f))
        controls.addView(analyse, LinearLayout.LayoutParams(0, 60, 1f))
        root.addView(controls)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tf = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("5m","15m","1H","4H","1D"))
        }
        val days = EditText(this).apply {
            hint = "Extension days"; setText("2"); inputType = 2
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        row.addView(tf, LinearLayout.LayoutParams(0, 60, 1f))
        row.addView(days, LinearLayout.LayoutParams(0, 60, 1f))
        root.addView(row)
        chart = ChartView(this)
        root.addView(chart, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(TextView(this).apply {
            text = "Prototype: upload a chart, then tap ANALYSE. Demo zones are drawn automatically."
            setTextColor(Color.LTGRAY); textSize = 13f
        })
        setContentView(root)
        upload.setOnClickListener { picker.launch("image/*") }
        analyse.setOnClickListener {
            if (selectedUri == null) Toast.makeText(this, "Please upload a chart first", Toast.LENGTH_SHORT).show()
            else chart.runDemoAnalysis()
        }
    }
}

class ChartView(context: android.content.Context) : View(context) {
    private var bmp: Bitmap? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var analysed = false
    fun setImage(b: Bitmap) { bmp = b; analysed = false; invalidate() }
    fun runDemoAnalysis() { analysed = true; invalidate() }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        c.drawColor(Color.rgb(15,18,24))
        bmp?.let {
            val dst = Rect(0,0,width,height)
            c.drawBitmap(it,null,dst,paint)
        } ?: run {
            paint.color = Color.GRAY; paint.textSize = 36f
            c.drawText("Upload chart screenshot", 40f, height/2f, paint)
        }
        if (!analysed || bmp == null) return
        // DEMO overlay. Replace these coordinates with AI/rule-engine output.
        drawZone(c, RectF(width*.12f,height*.62f,width*.88f,height*.78f),
            Color.rgb(0,190,120), "BULLISH ORDER BLOCK")
        drawZone(c, RectF(width*.38f,height*.25f,width*.95f,height*.39f),
            Color.rgb(235,80,80), "BEARISH OB → BREAKER")
        drawZone(c, RectF(width*.58f,height*.46f,width*.96f,height*.55f),
            Color.rgb(255,190,0), "REJECTION BLOCK")
    }
    private fun drawZone(c: Canvas, r: RectF, color: Int, label: String) {
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(55,Color.red(color),Color.green(color),Color.blue(color))
        c.drawRect(r,paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 4f; paint.color = color
        c.drawRect(r,paint)
        paint.strokeWidth = 2f
        c.drawLine(r.left,(r.top+r.bottom)/2,r.right,(r.top+r.bottom)/2,paint)
        paint.style = Paint.Style.FILL; paint.textSize = 22f; paint.color = Color.WHITE
        c.drawText(label,r.left+8,r.top+25,paint)
    }
}
